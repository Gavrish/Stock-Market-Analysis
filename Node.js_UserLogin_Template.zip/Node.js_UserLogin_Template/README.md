Node.js_UserLogin_Template
==========================

This is Node.js Login Template with a nice User Interface. If you want to use Node.js as plateform  and MongoDB  as Database then this demo project can be used as a starting point for your application.We'll be adding some more features in this application very soon. 

*************************************************************************************************************
###Requirements : 
*************************************************************************************************************
1.  Node.js
1.  MongoDB


*************************************************************************************************************
###Getting Started with Code  : 


*************************************************************************************************************
1.  Set Up MongoDB
1.  Start mongo: > mongo
1.  Set Up Node.js
1.  Clone code from https://github.com/knoldus/Node.js_UserLogin_Template.
1.  Run <code>npm install</code>
1.  Run <code>node app</code>
1.  Go to http://localhost:8080/
